

<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header"> 
 
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" id="myModalLabel"><i class='glyphicon glyphicon-edit'></i> Posible calificacion para la pregunta</h4>
<br>
<div class="bootstrap-iso">
 <div class="container-fluid">
  <div class="row">   
     <div class="form-group ">
      <label for="descripcion_estado">Calificacion</label><br>
          <select id="calificacion"></select><br>   
                       
     </div>

        <div class="modal-footer">         
          <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
          <button class="btn btn-success" id= "btn_save" name="save" type="submit"><i class="glyphicon glyphicon-floppy-disk"></i>Enviar Datos</button>
        </div>
      </div>
</div>

  </div>
