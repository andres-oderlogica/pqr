<?php
header("Location: factura/nueva_factura.php");
?>